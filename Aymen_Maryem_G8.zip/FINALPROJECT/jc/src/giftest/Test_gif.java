package giftest;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;

public class Test_gif extends JFrame {
    public Test_gif() {
        setBackground(new Color(255, 255, 255));
        setTitle("MD BANK");
        setBounds(100, 100, 701, 730);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JLabel label = null ;
     // ...

        ImageIcon img = null;
        try {
            img = new ImageIcon("insert.gif");
            
        } catch (Exception e) {
            e.printStackTrace();
            // Gérer l'exception (par exemple, afficher un message d'erreur)
        }

        if (img != null) {
            label = new JLabel(img);
            // Reste de votre code...
        }

       // ImageIcon img = new ImageIcon("insert.gif");
       // JLabel label = new JLabel(img);
        JPanel panel = new JPanel();
       // panel.add(label);
        panel.setBackground(new Color(255, 255, 255));
        panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, null, null));
        
        // Use a layout manager instead of null layout
        panel.setBounds(113, 136, 455, 240);
        panel.setLayout(null);

       // getContentPane().add(panel);
        add(label) ;
        setVisible(true);
    }

    public static void main(String[] args) {
        // Ensure Swing components are accessed on the EDT
        SwingUtilities.invokeLater(() -> new Test_gif());
    }
}
