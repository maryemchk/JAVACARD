/**
 * 
 */
/**
 * 
 */
module NewProject {
	requires java.desktop;
	requires apduio;
}