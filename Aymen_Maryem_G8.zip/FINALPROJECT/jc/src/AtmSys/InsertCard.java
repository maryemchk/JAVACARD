package AtmSys;



import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;



import java.awt.Font;

import java.awt.Color;

import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;

import javax.swing.JComboBox;
import java.awt.SystemColor;

public class InsertCard  {
	static Main main;
	protected JFrame frmMdBank;
	
	protected JLabel lblNewLabel_3 ;
	
	protected JPanel panel_3  ;

	protected  JButton btnNewButton;
	protected  JComboBox<String> card;
	protected JButton recu;
	protected ATM window;;
	
	//constructeur 
	public InsertCard(Main main,ATM window) {
		this.main=main;
		this.window=window;
		initialize();
		
		
	}
	
		
	  
	private void initialize() {

		frmMdBank = new JFrame();
		frmMdBank.getContentPane().setBackground(SystemColor.controlDkShadow);
		frmMdBank.setTitle("YourBank");
		frmMdBank.setBounds(100, 100, 701, 730);
		frmMdBank.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMdBank.setLocationRelativeTo(null);
		frmMdBank.getContentPane().setLayout(null);
		panel_3 = new JPanel();
		panel_3.setBounds(113, 136, 455, 240);
		panel_3.setBackground(new Color(240, 240, 240));
		panel_3.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, null, null));
		frmMdBank.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		lblNewLabel_3 = new JLabel("INSERT YOUR CARD PLEASE! ");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Simplified Arabic Fixed", Font.BOLD, 12));
		lblNewLabel_3.setBounds(0, 135, 455, 30);
		panel_3.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("    WELCOME TO YourBank");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Footlight MT Light", Font.BOLD, 26));
		lblNewLabel_2.setBounds(10, 10, 435, 50);
		panel_3.add(lblNewLabel_2);
		
		
		
		card = new JComboBox<String>();
		card.setBounds(278, 444, 131, 20);
		frmMdBank.getContentPane().add(card);
		String[] elementsToAdd = {"YourCard"};

	        for (String element : elementsToAdd) {
	            card.addItem(element);
	        }
	        card.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String selectedElement = (String) card.getSelectedItem();
            	    if (selectedElement != null ) {
						window.frmMdBank.setVisible(true);
				}
				}});
		
		
		
	}
}
